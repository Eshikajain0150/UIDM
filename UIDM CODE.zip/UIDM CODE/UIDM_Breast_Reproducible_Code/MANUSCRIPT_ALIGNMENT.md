# Mapping to UIDM-Breast manuscript submitted on 2026-11-03

This archive is a clean-room experimental reference. It must not be described as the original historical code or as replicating the article's numerical results until checkpoints and outputs have been authenticated.

| Manuscript specification | Source in code | Status |
|---|---|---|
| 780 BUSI images; 133 normal, 437 benign, 210 malignant | `uidm/datasets.py` | Manifest uses actual available input files; checks counts |
| 624 train, 78 validation, 78 test (image split) | `uidm/datasets.py` | Exact when supplied corpus has manuscript class counts; patient IDs unavailable unless user supplies them |
| Synthetic 7,800 pairs (6,240/780/780), 256×256 | `uidm/simulator.py`, YAML | Implemented reproducible generation; not original historical synthetic files |
| Normalized tissue proxies, lesion priors, anisotropic PSF, Rayleigh noise | `uidm/simulator.py`, YAML | Implemented reduced-order approximation; physical correctness not validated |
| Four-level U-Net, 2-layer conditioning encoder | `uidm/models.py` | Implemented concatenative conditioning at input scale |
| 200-step 0.0001–0.02 DDPM posterior reverse update | `uidm/diffusion.py` | Implemented; 50/100-step acceleration via DDIM (not full DDPM) |
| AdamW, 1e-4 LR, batch 8, weight decay 1e-4 | `uidm/train.py`, YAML | Implemented effective-batch accumulation |
| Five-block CNN, dropout 0.3, 3 outputs | `uidm/models.py` | Implemented |
| Five stochastic reconstructions; 0.010 variance; 0.55 entropy; 0.80 confidence | `uidm/train.py` | Implemented labeled/unlabeled training separation |
| Inferred pseudo-label confidence weights | `uidm/train.py` | Specific weighting equation is an explicit implementation choice; not verified historical formula |
| Joint diffusion/classifier training in Phase V | `uidm/train.py` | Frozen diffusion by default; optional pseudo-map self-distillation is an alternative, not proof of historical joint updates |
| Statistical tests, confidence intervals, class-specific metrics | `uidm/evaluation.py` | Computed from actual predictions, no printed manuscript results injected |
| Reported numerical claims | No fixed output values | **Not reproduced/validated; require original data and checkpoints** |
