@echo off
python -m pip install -r requirements.txt
python -m pytest -q
python -m uidm.cli smoke --out outputs\smoke
pause
