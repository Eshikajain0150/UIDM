import copy
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
import torch
from uidm.config import load_config,set_seed
from uidm.simulator import simulate_one
from uidm.models import ConditionalUNet,FiveBlockCNN
from uidm.diffusion import DDPM
from uidm.evaluation import metrics_from_predictions,paired_test

CONFIG=Path(__file__).resolve().parents[1]/'configs'/'paper_reference.yaml'


def small_cfg():
    c=load_config(CONFIG)
    c['image_size']=32
    c['model']['unet_channels']=[8,16,32,64]
    c['model']['condition_encoder_channels']=[4,8]
    c['model']['time_embedding_dim']=32
    c['model']['diffusion_steps']=8
    return c


def test_simulator_determinism_and_controls():
    c=small_cfg()
    a,b,y=simulate_one(4,c)
    aa,bb,yy=simulate_one(4,c)
    assert np.array_equal(a,aa) and np.array_equal(b,bb) and y==yy
    assert a.shape==(32,32) and b.min()>=0 and b.max()<=1
    assert simulate_one(4,c,class_neutral=True)[0].shape==(32,32)


def test_noise_prediction_and_sampling():
    c=small_cfg();set_seed(c['seed'])
    model=ConditionalUNet((8,16,32,64),(4,8),32)
    ddpm=DDPM(c,torch.device('cpu'))
    cond=torch.rand(1,1,32,32);latent=torch.rand_like(cond)
    loss=ddpm.loss(model,latent,cond)
    assert loss.item()>0
    loss.backward()
    result=ddpm.sample(model,cond,n_steps=4)
    assert result.shape==cond.shape and torch.isfinite(result).all()


def test_multiclass_metrics_and_paired():
    y=np.array([0,0,1,1,2,2])
    probs=np.array([[.9,.05,.05],[.7,.2,.1],[.1,.8,.1],[.15,.75,.1],[.2,.1,.7],[.1,.1,.8]])
    m=metrics_from_predictions(y,probs)
    assert m['n']==6 and m['accuracy']==1.0 and m['macro_auc_ovr']==1.0
    frame=pd.DataFrame({'id':list('abcdef'),'label':y,'pred':np.argmax(probs,1)})
    p=paired_test(frame,frame)
    assert p['exact_mcnemar_two_sided_p']==1.0 and p['n_pairs']==6


def test_classifier():
    model=FiveBlockCNN((8,8,16,16,16))
    assert model(torch.randn(2,1,32,32)).shape==(2,3)
