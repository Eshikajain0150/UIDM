"""UIDM-Breast independently runnable, evidence-generating research implementation."""
__version__ = "0.1.0"
