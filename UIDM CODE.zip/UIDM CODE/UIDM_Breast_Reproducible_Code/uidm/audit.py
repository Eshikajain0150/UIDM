"""Integrity report for reproducible image-level and patient-level split provenance."""
from collections import Counter
from pathlib import Path
import pandas as pd
from .datasets import validate_manifest,file_sha256,CLASSES
from .config import save_json


def audit_manifest(filename,out,verify_files=True):
    frame=pd.read_csv(filename,dtype={'id':str,'path':str,'split':str,'sha256':str})
    validate_manifest(frame)
    report={'manifest':str(Path(filename).resolve()),'n_images':int(len(frame)),'class_order':CLASSES,
            'partitions':{},'patient_disjoint_confirmed':False,'patient_ids_available':False}
    for split,g in frame.groupby('split'):
        report['partitions'][split]={'n':len(g),'class_counts':{
            CLASSES[i]:int((g.label==i).sum()) for i in range(3)}}
    has_patient=('patient_id' in frame and frame.patient_id.notna().all()
        and frame.patient_id.astype(str).str.strip().ne('').all())
    report['patient_ids_available']=bool(has_patient)
    if has_patient:
        report['patient_disjoint_confirmed']=bool(frame.groupby('patient_id').split.nunique().max()==1)
        report['n_unique_patients']=int(frame.patient_id.nunique())
    if verify_files:
        bad=[]
        for _,r in frame.iterrows():
            p=Path(r.path)
            if not p.is_file():bad.append({'id':r.id,'issue':'missing'});continue
            if file_sha256(p)!=r.sha256:bad.append({'id':r.id,'issue':'sha256_mismatch'})
        report['missing_or_modified_files']=bad
        report['files_verified']=len(frame)-len(bad)
    save_json(report,out)
    if verify_files and report['missing_or_modified_files']:
        raise ValueError(f"Integrity audit detected {len(report['missing_or_modified_files'])} missing/modified files")
    return report
