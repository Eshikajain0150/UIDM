"""Run as python -m uidm.cli COMMAND --help"""
import argparse
from pathlib import Path
import copy
import json
import pandas as pd
import torch
from .config import load_config,set_seed,get_device,save_json
from .datasets import create_manifest,validate_manifest
from .audit import audit_manifest
from .train import (train_ddpm,train_classifier,build_features,train_deterministic,
                    evaluate_classifier,adapt_classifier,evaluate_reconstruction)
from .evaluation import paired_test
from .models import make_ddpm,make_classifier
from .diffusion import DDPM
from .simulator import SyntheticPairs
from .train import load_weights
from torch.utils.data import DataLoader
import numpy as np

DEFAULT=str(Path(__file__).resolve().parent.parent/'configs'/'paper_reference.yaml')


def main():
    p=argparse.ArgumentParser(description='UIDM-Breast reproducible research implementation; no hardcoded results')
    p.add_argument('--config',default=DEFAULT)
    sub=p.add_subparsers(dest='command',required=True)
    sp=sub.add_parser('prepare',help='Create immutable BUSI split manifest')
    sp.add_argument('--busi',required=True);sp.add_argument('--out',required=True);sp.add_argument('--patient-csv')
    sp=sub.add_parser('audit');sp.add_argument('--manifest',required=True);sp.add_argument('--out',required=True)
    sp=sub.add_parser('train-ddpm');sp.add_argument('--out',required=True);sp.add_argument('--epochs',type=int);sp.add_argument('--limit',type=int);sp.add_argument('--size',type=int);sp.add_argument('--class-neutral',action='store_true');sp.add_argument('--resume')
    sp=sub.add_parser('train-deterministic');sp.add_argument('--out',required=True);sp.add_argument('--epochs',type=int,default=50);sp.add_argument('--limit',type=int)
    sp=sub.add_parser('evaluate-reconstruction');sp.add_argument('--ddpm',required=True);sp.add_argument('--split',choices=['train','val','test'],default='test');sp.add_argument('--steps',type=int,default=200);sp.add_argument('--limit',type=int);sp.add_argument('--out',required=True)
    sp=sub.add_parser('build-features');sp.add_argument('--manifest',required=True);sp.add_argument('--split',choices=['train','val','test'],required=True);sp.add_argument('--ddpm',required=True);sp.add_argument('--out',required=True);sp.add_argument('--mode',choices=['uidm','deterministic'],default='uidm');sp.add_argument('--steps',type=int,default=200)
    sp=sub.add_parser('train-classifier');sp.add_argument('--manifest');sp.add_argument('--out',required=True);sp.add_argument('--mode',choices=['synthetic','raw','clahe','median','uidm','deterministic'],default='raw');sp.add_argument('--train-cache');sp.add_argument('--val-cache');sp.add_argument('--init');sp.add_argument('--epochs',type=int);sp.add_argument('--limit',type=int)
    sp=sub.add_parser('adapt');sp.add_argument('--manifest',required=True);sp.add_argument('--ddpm',required=True);sp.add_argument('--classifier',required=True);sp.add_argument('--out',required=True);sp.add_argument('--steps',type=int,default=200);sp.add_argument('--limit',type=int);sp.add_argument('--update-ddpm',action='store_true')
    sp=sub.add_parser('evaluate');sp.add_argument('--manifest',required=True);sp.add_argument('--split',choices=['train','val','test'],required=True);sp.add_argument('--classifier',required=True);sp.add_argument('--mode',choices=['raw','clahe','median','uidm','deterministic']);sp.add_argument('--cache');sp.add_argument('--out',required=True);sp.add_argument('--bootstrap',type=int);sp.add_argument('--limit',type=int)
    sp=sub.add_parser('compare');sp.add_argument('--pred-a',required=True);sp.add_argument('--pred-b',required=True);sp.add_argument('--out',required=True);sp.add_argument('--bootstrap',type=int)
    sp=sub.add_parser('smoke',help='Small synthetic CPU/GPU test with ACTUAL computed loss')
    sp.add_argument('--out',default='outputs/smoke')
    args=p.parse_args();cfg=load_config(args.config);set_seed(cfg['seed'])
    if args.command=='prepare':
        df,method=create_manifest(args.busi,args.out,cfg['seed'],args.patient_csv)
        print(df.groupby(['split','label']).size().to_string());print('Split method:',method)
    elif args.command=='audit':print(json.dumps(audit_manifest(args.manifest,args.out),indent=2))
    elif args.command=='train-ddpm':train_ddpm(cfg,args.out,args.epochs,args.limit,args.size,args.class_neutral,args.resume)
    elif args.command=='train-deterministic':train_deterministic(cfg,args.out,args.epochs,args.limit)
    elif args.command=='evaluate-reconstruction':evaluate_reconstruction(cfg,args.ddpm,args.out,args.split,args.steps,args.limit)
    elif args.command=='build-features':print(build_features(cfg,args.manifest,args.split,args.ddpm,args.out,args.mode,args.steps))
    elif args.command=='train-classifier':train_classifier(cfg,args.out,args.manifest,args.mode,args.train_cache,args.val_cache,args.init,args.epochs,args.limit)
    elif args.command=='adapt':adapt_classifier(cfg,args.manifest,args.ddpm,args.classifier,args.out,args.steps,args.limit,args.update_ddpm)
    elif args.command=='evaluate':
        if args.mode in ('uidm','deterministic') and not args.cache:
            raise ValueError('For inversion inputs, first generate a split-specific feature cache with build-features')
        evaluate_classifier(cfg,args.manifest,args.split,args.classifier,args.out,args.mode,args.cache,args.bootstrap or cfg['reporting']['bootstrap_rounds'],args.limit)
    elif args.command=='compare':
        a=pd.read_csv(args.pred_a);b=pd.read_csv(args.pred_b)
        result=paired_test(a,b,args.bootstrap or cfg['reporting']['bootstrap_rounds'],cfg['seed']);save_json(result,args.out)
        print(json.dumps(result,indent=2))
    elif args.command=='smoke':
        cfg=copy.deepcopy(cfg)
        cfg['image_size']=32
        cfg['model']['unet_channels']=[8,16,32,64]
        cfg['model']['condition_encoder_channels']=[4,8]
        cfg['model']['time_embedding_dim']=32
        cfg['model']['diffusion_steps']=6
        cfg['training']['diffusion_batch_size']=4
        cfg['training']['diffusion_micro_batch_size']=2
        cfg['training']['classifier_batch_size']=4
        cfg['synthetic'].update(total=30,train=18,val=6,test=6)
        output=Path(args.out)
        checkpoint=train_ddpm(cfg,output/'diffusion',epochs=1,limit=8,size=32)
        device=get_device();model=make_ddpm(cfg).to(device);load_weights(model,checkpoint,device)
        us,tissue,_=next(iter(DataLoader(SyntheticPairs(cfg,'test',size=32),batch_size=2)))
        predicted=DDPM(cfg,device).sample(model,us.to(device),n_steps=6)
        val=float(torch.nn.functional.mse_loss(predicted.cpu(),tissue))
        save_json({'actual_smoke_reconstruction_mse':val,'shape':list(predicted.shape),
                   'note':'Smoke test only, NOT manuscript results'},output/'smoke_result.json')
        print('PASS: smoke sample shape',tuple(predicted.shape),'actual_mse',val)

if __name__=='__main__':main()
