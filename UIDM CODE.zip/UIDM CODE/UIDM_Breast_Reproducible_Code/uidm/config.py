from pathlib import Path
import json
import random
import numpy as np
import torch
import yaml


def load_config(path):
    with open(path, encoding='utf-8') as f:
        return yaml.safe_load(f)


def set_seed(seed):
    random.seed(int(seed))
    np.random.seed(int(seed))
    torch.manual_seed(int(seed))
    if not torch.cuda.is_available():
        torch.set_num_threads(min(4,torch.get_num_threads()))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(int(seed))
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except AttributeError:
        pass


def get_device():
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def save_json(data, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, default=str, allow_nan=False)


def env_record():
    return {
        'torch': torch.__version__,
        'cuda_available': torch.cuda.is_available(),
        'gpu': torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        'cuda_runtime': torch.version.cuda,
        'device_count': torch.cuda.device_count(),
    }
