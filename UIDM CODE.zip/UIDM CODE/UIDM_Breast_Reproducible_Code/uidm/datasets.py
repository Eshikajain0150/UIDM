"""BUSI manifest creation and preprocessing. Never treats image-level splits as patient-disjoint."""
from pathlib import Path
import hashlib
import numpy as np
import pandas as pd
from PIL import Image
import cv2
import torch
from torch.utils.data import Dataset
from sklearn.model_selection import train_test_split, StratifiedGroupKFold

CLASSES=['normal','benign','malignant']
LABELS={name:i for i,name in enumerate(CLASSES)}
EXPECTED={'normal':(106,13,14),'benign':(350,44,43),'malignant':(168,21,21)}


def file_sha256(filename):
    h=hashlib.sha256()
    with open(filename,'rb') as f:
        for x in iter(lambda:f.read(1024*1024),b''): h.update(x)
    return h.hexdigest()


def scan_busi(root):
    root=Path(root); records=[]
    for p in sorted(root.rglob('*')):
        if p.suffix.lower() not in ('.png','.jpg','.jpeg','.bmp','.tif','.tiff'):continue
        if '_mask' in p.stem.lower() or 'mask' in p.parent.name.lower():continue
        parts={s.lower().strip() for s in p.parts}
        matches=[s for s in CLASSES if s in parts]
        if len(matches)!=1:continue
        records.append(dict(id=p.relative_to(root).as_posix(),path=str(p.resolve()),label=LABELS[matches[0]],patient_id=''))
    if not records:raise ValueError('No class-folder images found; expected normal/, benign/, malignant/.')
    return pd.DataFrame(records)


def create_manifest(root,out,seed=42,patient_csv=None):
    df=scan_busi(root)
    if patient_csv:
        patients=pd.read_csv(patient_csv,dtype=str)
        if not {'id','patient_id'}.issubset(patients.columns):raise ValueError('patient_csv needs id,patient_id columns')
        df=df.drop(columns='patient_id').merge(patients[['id','patient_id']],on='id',how='left',validate='one_to_one')
        if df.patient_id.isna().any():raise ValueError('Every image needs a patient_id for group split')
        ids=np.arange(len(df)); y=df.label.values; groups=df.patient_id.values
        cv=StratifiedGroupKFold(n_splits=10,shuffle=True,random_state=seed)
        rem,test=next(cv.split(ids,y,groups))
        cv2_=StratifiedGroupKFold(n_splits=9,shuffle=True,random_state=seed+1)
        train_idx_rel,val_idx_rel=next(cv2_.split(rem,y[rem],groups[rem]))
        train,val=rem[train_idx_rel],rem[val_idx_rel]
        strategy='patient_grouped_stratified_approx_80_10_10'
        if set(groups[train])&set(groups[val]) or set(groups[train])&set(groups[test]) or set(groups[val])&set(groups[test]):
            raise AssertionError('Patient leakage')
    else:
        # If the published BUSI counts are present, retain the exact manuscript class-wise allocation.
        df=df.sort_values('id').reset_index(drop=True)
        rng=np.random.default_rng(seed)
        train=[];val=[];test=[]
        for name,idx in LABELS.items():
            positions=np.where(df.label.to_numpy()==idx)[0]
            rng.shuffle(positions)
            counts=EXPECTED[name] if len(positions)==sum(EXPECTED[name]) else (
                round(.8*len(positions)),round(.1*len(positions)),0)
            ntr,nv=counts[:2]
            train.extend(positions[:ntr]);val.extend(positions[ntr:ntr+nv]);test.extend(positions[ntr+nv:])
        strategy='image_level_stratified_NOT_patient_disjoint'
    split=np.empty(len(df),dtype=object)
    split[train]='train';split[val]='val';split[test]='test'
    df['split']=split
    df['sha256']=[file_sha256(p) for p in df.path]
    # Duplicate file contents in multiple partitions cannot be treated as independent.
    duplicate=df.groupby('sha256').split.nunique()
    if (duplicate>1).any():raise ValueError('Duplicate image content found across partitions; fix source dataset.')
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(out,index=False)
    (out.parent/(out.stem+'_split_method.txt')).write_text(strategy+'\n',encoding='utf-8')
    return df,strategy


def validate_manifest(df, require_patient_disjoint=False):
    if df.id.duplicated().any():raise ValueError('Duplicate image identifiers')
    if not set(df.split).issubset({'train','val','test'}):raise ValueError('Unknown split')
    if not set(df.label).issubset({0,1,2}):raise ValueError('Unknown class')
    if df.groupby('sha256').split.nunique().max()>1:raise ValueError('File hash leakage')
    if require_patient_disjoint:
        if df.patient_id.isna().any() or (df.patient_id.astype(str).str.strip()=='').any():
            raise ValueError('Patient identifiers missing; cannot assert patient-disjoint.')
        if df.groupby('patient_id').split.nunique().max()>1:raise ValueError('Patient leakage')


def preprocess(path,side=256,method='raw'):
    im=np.array(Image.open(path).convert('L').resize((side,side),Image.Resampling.BILINEAR),dtype=np.uint8)
    if method in ('clahe','uidm','deterministic'):
        clahe=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(8,8))
        im=clahe.apply(im)
    elif method=='median':
        im=cv2.medianBlur(im,5)
    elif method!='raw':raise ValueError('Unknown preprocessing method')
    x=im.astype(np.float32)/255.
    return x[None]


class BusiDataset(Dataset):
    def __init__(self,manifest,split,side=256,preprocess_mode='raw',subset_ids=None):
        self.df=pd.read_csv(manifest).query('split == @split').reset_index(drop=True)
        if subset_ids is not None:self.df=self.df[self.df.id.isin(subset_ids)].reset_index(drop=True)
        self.side,self.mode=side,preprocess_mode
    def __len__(self):return len(self.df)
    def __getitem__(self,i):
        row=self.df.iloc[i]
        x=preprocess(row.path,self.side,self.mode)
        return torch.tensor(x),torch.tensor(int(row.label)),row.id
