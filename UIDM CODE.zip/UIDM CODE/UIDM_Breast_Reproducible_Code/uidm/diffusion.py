"""DDPM noise prediction; standard fixed posterior reverse variance; DDIM optional sampling."""
import numpy as np
import torch
import torch.nn.functional as F


class DDPM:
    def __init__(self,cfg,device):
        m=cfg['model']
        self.T=int(m['diffusion_steps']);self.device=device
        self.betas=torch.linspace(float(m['beta_start']),float(m['beta_end']),self.T,device=device)
        self.alphas=1-self.betas
        self.ac=torch.cumprod(self.alphas,dim=0)
        self.ac_prev=torch.cat([torch.ones(1,device=device),self.ac[:-1]])
        self.posterior_var=self.betas*(1-self.ac_prev)/(1-self.ac).clamp_min(1e-12)

    def loss(self,model,clean,condition):
        b=clean.shape[0]
        t=torch.randint(0,self.T,(b,),device=clean.device)
        noise=torch.randn_like(clean)
        ac=self.ac[t][:,None,None,None]
        noisy=ac.sqrt()*clean+(1-ac).sqrt()*noise
        pred=model(noisy,t,condition)
        return F.mse_loss(pred,noise)

    @torch.no_grad()
    def sample(self,model,condition,n_steps=None,eta=1.0):
        model.eval()
        b=condition.size(0)
        x=torch.randn_like(condition)
        steps=self.T if n_steps is None else int(n_steps)
        if steps<1 or steps>self.T:raise ValueError('n_steps must be 1..T')
        schedule=np.linspace(0,self.T-1,steps,dtype=np.int64)
        schedule=np.unique(schedule)
        # Full schedule: exact DDPM reverse-posterior parameterization.
        if len(schedule)==self.T:
            for idx in reversed(range(self.T)):
                t=torch.full((b,),idx,device=condition.device,dtype=torch.long)
                eps=model(x,t,condition)
                mean=(x-self.betas[idx]/(1-self.ac[idx]).sqrt()*eps)/self.alphas[idx].sqrt()
                if idx>0:x=mean+self.posterior_var[idx].clamp_min(0).sqrt()*torch.randn_like(x)
                else:x=mean
        else:
            # Skipped schedule uses generalized DDIM with eta noise, not a full-step DDPM update.
            for j in reversed(range(len(schedule))):
                idx=int(schedule[j]);previous=int(schedule[j-1]) if j>0 else -1
                t=torch.full((b,),idx,device=condition.device,dtype=torch.long)
                eps=model(x,t,condition)
                at=self.ac[idx];ap=self.ac[previous] if previous>=0 else torch.tensor(1.,device=self.device)
                x0=(x-(1-at).sqrt()*eps)/at.sqrt()
                sigma=eta*(((1-ap)/(1-at))*((1-at/ap).clamp_min(0))).clamp_min(0).sqrt()
                direction=((1-ap)-sigma**2).clamp_min(0).sqrt()*eps
                x=ap.sqrt()*x0+direction+(sigma*torch.randn_like(x) if previous>=0 else 0)
        return x.clamp(0,1)

    @torch.no_grad()
    def multiple_reconstructions(self,model,condition,K=5,n_steps=None):
        return torch.stack([self.sample(model,condition,n_steps) for _ in range(K)],dim=0)
