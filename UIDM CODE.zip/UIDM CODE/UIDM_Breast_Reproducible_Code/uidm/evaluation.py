"""Compute all reported metrics exclusively from held-out predictions; never prefill results."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.metrics import (confusion_matrix,roc_auc_score,precision_recall_fscore_support,
    accuracy_score,balanced_accuracy_score,cohen_kappa_score)
from scipy.stats import binomtest
from .config import save_json

CLASSES=['normal','benign','malignant']


def metrics_from_predictions(y,prob,bins=10):
    y=np.asarray(y,dtype=int); prob=np.asarray(prob,dtype=float)
    if prob.shape!=(len(y),3):raise ValueError('Need one 3-class probability vector per observation')
    if not np.isfinite(prob).all():raise ValueError('Nonfinite probabilities')
    if np.max(np.abs(prob.sum(axis=1)-1))>.01:raise ValueError('Probabilities must sum to 1')
    pred=prob.argmax(1)
    conf=confusion_matrix(y,pred,labels=[0,1,2]);total=conf.sum()
    tp=np.diag(conf).astype(float);fn=conf.sum(1)-tp;fp=conf.sum(0)-tp;tn=total-tp-fp-fn
    precision,recall,f1,_=precision_recall_fscore_support(y,pred,labels=[0,1,2],zero_division=0)
    specificity=np.divide(tn,tn+fp,out=np.zeros_like(tn),where=(tn+fp)>0)
    aucs=[]
    for i in range(3):
        binary=(y==i).astype(int)
        aucs.append(float(roc_auc_score(binary,prob[:,i])) if len(np.unique(binary))==2 else None)
    ent=-np.sum(prob*np.log(np.maximum(prob,1e-12)),axis=1)
    hits=(pred==y)
    confmax=prob.max(1);ece=0.
    for low,high in zip(np.linspace(0,1,bins+1)[:-1],np.linspace(0,1,bins+1)[1:]):
        mask=(confmax>=low)&(confmax<(high if high<1 else 1.0000001))
        if mask.any():ece+=mask.mean()*abs(hits[mask].mean()-confmax[mask].mean())
    onehot=np.eye(3)[y]
    per=[]
    for i,name in enumerate(CLASSES):
        per.append({'class':name,'support':int((y==i).sum()),'sensitivity':float(recall[i]),
                    'specificity':float(specificity[i]),'precision':float(precision[i]),
                    'f1':float(f1[i]),'auc_ovr':aucs[i]})
    return {'n':int(total),'accuracy':float(accuracy_score(y,pred)),'balanced_accuracy':float(balanced_accuracy_score(y,pred)),
            'macro_precision':float(precision.mean()),'macro_sensitivity':float(recall.mean()),
            'macro_specificity':float(specificity.mean()),'macro_f1':float(f1.mean()),
            'macro_auc_ovr':float(np.mean(aucs)) if all(a is not None for a in aucs) else None,
            'ece':float(ece),'multiclass_brier':float(np.mean(np.sum((prob-onehot)**2,axis=1))),
            'mean_predictive_entropy_nats':float(ent.mean()),'confusion_matrix':conf.astype(int).tolist(),
            'class_specific':per}


def bootstrap_ci(y,prob,n_boot=2000,seed=42,keys=None):
    rng=np.random.default_rng(seed);n=len(y)
    if keys is None:keys=['accuracy','macro_auc_ovr','macro_f1','macro_specificity','ece','multiclass_brier']
    vals={k:[] for k in keys}
    class_keys=('sensitivity','specificity','precision','f1','auc_ovr')
    per_class={name:{key:[] for key in class_keys} for name in CLASSES}
    y=np.asarray(y);prob=np.asarray(prob)
    # Stratified bootstrap maintains at least one example per observed class.
    idx_by_class=[np.where(y==i)[0] for i in range(3)]
    for _ in range(n_boot):
        ii=np.concatenate([rng.choice(v,len(v),replace=True) for v in idx_by_class if len(v)])
        result=metrics_from_predictions(y[ii],prob[ii]);
        for k in keys:
            if result[k] is not None:vals[k].append(result[k])
        for entry in result['class_specific']:
            for key in class_keys:
                if entry[key] is not None:per_class[entry['class']][key].append(entry[key])
    bounds=lambda a: [float(np.quantile(a,.025)),float(np.quantile(a,.975))] if a else None
    return ({k:bounds(v) for k,v in vals.items()},
            {name:{key:bounds(values) for key,values in dat.items()} for name,dat in per_class.items()})


def paired_test(dfA,dfB,n_boot=2000,seed=42):
    if dfA.id.duplicated().any() or dfB.id.duplicated().any():raise ValueError('Duplicate IDs')
    x=dfA.merge(dfB,on='id',how='outer',suffixes=('_a','_b'),indicator=True)
    if not (x._merge=='both').all():raise ValueError('Paired models must evaluate identical image IDs')
    if not (x.label_a==x.label_b).all():raise ValueError('Ground truth differs')
    correct_a=(x.pred_a==x.label_a);correct_b=(x.pred_b==x.label_b)
    b=int((correct_a&~correct_b).sum());c=int((~correct_a&correct_b).sum())
    exact_p=float(binomtest(min(b,c),b+c,p=.5).pvalue) if b+c else 1.0
    rng=np.random.default_rng(seed);diff=[]
    for _ in range(n_boot):
        ix=rng.integers(0,len(x),size=len(x));diff.append(float(correct_b.iloc[ix].mean()-correct_a.iloc[ix].mean()))
    return {'n_pairs':len(x),'a_correct_b_incorrect':b,'a_incorrect_b_correct':c,
            'accuracy_difference_b_minus_a':float(correct_b.mean()-correct_a.mean()),
            'paired_accuracy_difference_95ci':list(np.quantile(diff,[.025,.975])),
            'exact_mcnemar_two_sided_p':exact_p,
            'note':'Exact McNemar p is unadjusted; apply Holm across actual planned comparisons.'}


def write_prediction_report(frame,out,seed=42,boot=2000):
    frame=frame.copy();frame=frame.sort_values('id').reset_index(drop=True)
    path=Path(out);path.mkdir(parents=True,exist_ok=True)
    frame.to_csv(path/'predictions.csv',index=False)
    y=frame.label.to_numpy(dtype=int);prob=frame[['p_normal','p_benign','p_malignant']].to_numpy(float)
    report=metrics_from_predictions(y,prob)
    report['bootstrap_95ci'],report['class_specific_95ci']=bootstrap_ci(y,prob,boot,seed)
    save_json(report,path/'metrics.json')
    pd.DataFrame(report['confusion_matrix'],index=CLASSES,columns=CLASSES).to_csv(path/'confusion_matrix.csv')
    pd.DataFrame(report['class_specific']).to_csv(path/'class_metrics.csv',index=False)
    return report
