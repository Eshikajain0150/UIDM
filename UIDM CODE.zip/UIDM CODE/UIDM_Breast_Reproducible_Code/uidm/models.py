import math
import torch
from torch import nn
import torch.nn.functional as F


def make_norm(c):
    return nn.GroupNorm(min(8,c),c)


class TimeEmbedding(nn.Module):
    def __init__(self,dim):
        super().__init__();self.dim=dim
        self.net=nn.Sequential(nn.Linear(dim,dim*2),nn.SiLU(),nn.Linear(dim*2,dim))
    def forward(self,t):
        half=self.dim//2
        freqs=torch.exp(-math.log(10000)*torch.arange(half,device=t.device,dtype=torch.float32)/max(half-1,1))
        arg=t.float()[:,None]*freqs[None]
        pos=torch.cat([arg.sin(),arg.cos()],dim=1)
        if self.dim%2:pos=F.pad(pos,(0,1))
        return self.net(pos)


class ResBlock(nn.Module):
    def __init__(self,cin,cout,tdim):
        super().__init__()
        self.a=nn.Conv2d(cin,cout,3,padding=1)
        self.b=nn.Conv2d(cout,cout,3,padding=1)
        self.n1=make_norm(cout);self.n2=make_norm(cout)
        self.t=nn.Linear(tdim,cout)
        self.skip=nn.Conv2d(cin,cout,1) if cin!=cout else nn.Identity()
    def forward(self,x,time):
        h=F.silu(self.n1(self.a(x)))
        h=h+self.t(time)[:,:,None,None]
        h=self.n2(self.b(F.silu(h)))
        return F.silu(h+self.skip(x))


class ConditionalUNet(nn.Module):
    """Four-level U-Net, 2-layer conditioning encoder, input feature concatenation."""
    def __init__(self,channels=(64,128,256,512),cond_channels=(32,64),tdim=128):
        super().__init__()
        c=list(map(int,channels))
        assert len(c)==4
        self.cond=nn.Sequential(nn.Conv2d(1,cond_channels[0],3,padding=1),nn.SiLU(),
                                nn.Conv2d(cond_channels[0],cond_channels[1],3,padding=1),nn.SiLU())
        self.temb=TimeEmbedding(tdim)
        self.enc=nn.ModuleList()
        cin=1+cond_channels[1]
        for co in c:
            self.enc.append(ResBlock(cin,co,tdim));cin=co
        self.mid=ResBlock(c[-1],c[-1],tdim)
        self.dec=nn.ModuleList()
        cin=c[-1]
        for co in reversed(c):
            self.dec.append(ResBlock(cin+co,co,tdim));cin=co
        self.out=nn.Conv2d(c[0],1,1)
    def forward(self,noisy,t,ultrasound):
        if noisy.shape[-1]%8 or noisy.shape[-2]%8:
            raise ValueError('Image dimensions must be divisible by 8')
        te=self.temb(t)
        cond=self.cond(ultrasound)
        h=torch.cat([noisy,cond],dim=1)
        feats=[]
        for i,block in enumerate(self.enc):
            h=block(h,te);feats.append(h)
            if i<len(self.enc)-1:h=F.avg_pool2d(h,2)
        h=self.mid(h,te)
        for i,block in enumerate(self.dec):
            skip=feats[-i-1]
            if h.shape[-2:]!=skip.shape[-2:]:h=F.interpolate(h,size=skip.shape[-2:],mode='nearest')
            h=block(torch.cat([h,skip],dim=1),te)
        return self.out(h)


class FiveBlockCNN(nn.Module):
    def __init__(self,channels=(32,64,128,256,256),dropout=0.30):
        super().__init__()
        layers=[];cin=1
        for co in channels:
            layers.extend([nn.Conv2d(cin,co,3,padding=1),nn.BatchNorm2d(co),nn.ReLU(inplace=True),nn.MaxPool2d(2)])
            cin=co
        self.features=nn.Sequential(*layers)
        self.classifier=nn.Sequential(nn.AdaptiveAvgPool2d(1),nn.Flatten(),nn.Dropout(dropout),nn.Linear(cin,3))
    def forward(self,x):return self.classifier(self.features(x))


class DeterministicUNet(nn.Module):
    """Simpler non-diffusion reconstruction control on the SAME synthetic pairs."""
    def __init__(self,base=32):
        super().__init__()
        def block(cin,cout):return nn.Sequential(nn.Conv2d(cin,cout,3,padding=1),nn.ReLU(),nn.Conv2d(cout,cout,3,padding=1),nn.ReLU())
        self.e1=block(1,base);self.e2=block(base,base*2);self.e3=block(base*2,base*4)
        self.d2=block(base*6,base*2);self.d1=block(base*3,base)
        self.last=nn.Conv2d(base,1,1)
    def forward(self,x):
        a=self.e1(x);b=self.e2(F.avg_pool2d(a,2));c=self.e3(F.avg_pool2d(b,2))
        z=self.d2(torch.cat([F.interpolate(c,size=b.shape[-2:],mode='nearest'),b],1))
        z=self.d1(torch.cat([F.interpolate(z,size=a.shape[-2:],mode='nearest'),a],1))
        return torch.sigmoid(self.last(z))


def make_ddpm(cfg):
    return ConditionalUNet(cfg['model']['unet_channels'],cfg['model']['condition_encoder_channels'],cfg['model']['time_embedding_dim'])


def make_classifier(cfg):
    return FiveBlockCNN(cfg['model']['classifier_channels'],cfg['model']['dropout'])
