"""Deterministic-on-index reduced-order breast ultrasound simulator.

Normalized tissue proxies are NOT physically calibrated acoustic-impedance maps.
Class-neutral geometry is an experimental control. Physical reference validation
is out of scope.
"""
import numpy as np
from scipy.ndimage import gaussian_filter, sobel
import torch
from torch.utils.data import Dataset


def simulate_one(index, cfg, seed=42, image_size=None, class_neutral=None):
    c = cfg['synthetic']
    side = int(image_size or cfg['image_size'])
    rng = np.random.default_rng(int(seed) * 1000003 + int(index))
    yy, xx = np.mgrid[:side, :side]
    label = int(index % 3)  # 0 normal, 1 benign, 2 malignant (balanced synthetic labels)
    scale = side / 256.0
    boundary = side * rng.uniform(.25, .45)
    gland = yy >= boundary + 3*scale*np.sin(xx/(side*.25)+rng.uniform(0, 6.28))
    tissue = rng.normal(c['adipose_proxy_mean'], c['adipose_proxy_sd'], (side,side))
    tissue[gland] = rng.normal(c['glandular_proxy_mean'], c['glandular_proxy_sd'], gland.sum())
    # The anatomical perturbation is defined in normalized proxy units.
    tissue += rng.normal(0, c['anatomical_noise_sd'], (side,side))
    neutral = c['class_neutral_geometry'] if class_neutral is None else class_neutral
    if label:
        a = rng.uniform(*c['lesion_axis_major']) * scale
        b = rng.uniform(*c['lesion_axis_minor']) * scale
        cx, cy = rng.uniform(.28,.72)*side, rng.uniform(.40,.78)*side
        theta = rng.uniform(-np.pi/4,np.pi/4)
        dx,dy = xx-cx, yy-cy
        u = dx*np.cos(theta)+dy*np.sin(theta)
        v = -dx*np.sin(theta)+dy*np.cos(theta)
        polar = np.arctan2(v/b,u/a)
        r = np.sqrt((u/a)**2+(v/b)**2)
        # In the class-neutral control both lesion categories share geometry/contrast priors.
        irregular = bool(rng.integers(0,2)) if neutral else (label==2)
        amp = rng.uniform(0.08, 0.16) if neutral else rng.uniform(
            c['benign_contrast_min'] if label==1 else c['malignant_contrast_min'],
            c['benign_contrast_max'] if label==1 else c['malignant_contrast_max'])
        if irregular:
            r = r/(1+0.17*np.sin(7*polar+0.4)+0.10*np.sin(11*polar+1.7))
        lesion = r <= 1.0
        tissue[lesion] += amp
    tissue = np.clip(tissue,0,1).astype(np.float32)
    reflect = np.hypot(sobel(tissue,axis=0),sobel(tissue,axis=1))
    blurred = gaussian_filter(reflect, (c['psf_axial_sigma']*scale,c['psf_lateral_sigma']*scale))
    atten = np.exp(-c['attenuation']*yy/max(1,side-1))
    speckle = rng.rayleigh(scale=1.0,size=(side,side))
    speckle /= np.sqrt(np.pi/2)
    out = blurred*atten*(1+c['speckle']*(speckle-1))
    # Distinct from anatomical Gaussian variation in the tissue proxy.
    out = np.maximum(out,0)
    out = out/(np.percentile(out,99.5)+1e-8)
    out = np.clip(out,0,1).astype(np.float32)
    return out, tissue, label


class SyntheticPairs(Dataset):
    def __init__(self,cfg,split='train',size=None,class_neutral=None):
        self.cfg,self.split,self.side,self.class_neutral=cfg,split,size,class_neutral
        num=cfg['synthetic']['total']
        train,val=cfg['synthetic']['train'],cfg['synthetic']['val']
        assert train+val+cfg['synthetic']['test']==num
        offsets={'train':(0,train),'val':(train,val),'test':(train+val,num-train-val)}
        self.offset,self.length=offsets[split]
    def __len__(self):return self.length
    def __getitem__(self, i):
        ultra,tissue,y=simulate_one(self.offset+i,self.cfg,self.cfg['seed'],self.side,self.class_neutral)
        return (torch.from_numpy(ultra[None]),torch.from_numpy(tissue[None]),torch.tensor(y,dtype=torch.long))
