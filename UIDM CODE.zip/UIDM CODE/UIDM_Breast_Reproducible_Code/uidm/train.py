import copy
import hashlib
from pathlib import Path
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import Dataset,DataLoader
import pandas as pd
from .config import set_seed,get_device,save_json,env_record
from .simulator import SyntheticPairs
from .datasets import BusiDataset,preprocess,validate_manifest
from .models import make_ddpm,make_classifier,DeterministicUNet
from .diffusion import DDPM
from .evaluation import write_prediction_report


def load_weights(model,filename,device):
    payload=torch.load(filename,map_location=device,weights_only=False)
    model.load_state_dict(payload['state_dict'])
    return payload


def save_checkpoint(model,output,epoch,cfg,validation_loss,kind,extra=None,optimizer=None,scheduler=None,scaler=None):
    p=Path(output);p.parent.mkdir(parents=True,exist_ok=True)
    payload={'state_dict':model.state_dict(),'epoch':epoch,'validation_loss':float(validation_loss),
             'kind':kind,'config':cfg,'extra':extra or {}}
    if optimizer is not None:
        payload['optimizer_state']=optimizer.state_dict()
        payload['rng_torch']=torch.get_rng_state()
        if torch.cuda.is_available():payload['rng_cuda']=torch.cuda.get_rng_state_all()
    if scheduler is not None:payload['scheduler_state']=scheduler.state_dict()
    if scaler is not None:payload['scaler_state']=scaler.state_dict()
    torch.save(payload,p)


def train_ddpm(cfg,out,epochs=None,limit=None,size=None,neutral=False,resume=None):
    set_seed(cfg['seed']);device=get_device();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    model=make_ddpm(cfg).to(device)
    resumed=load_weights(model,resume,device) if resume else None
    diffusion=DDPM(cfg,device)
    train=SyntheticPairs(cfg,'train',size,neutral);val=SyntheticPairs(cfg,'val',size,neutral)
    if limit:train=torch.utils.data.Subset(train,range(min(limit,len(train))));val=torch.utils.data.Subset(val,range(min(max(4,limit//4),len(val))))
    opt=torch.optim.AdamW(model.parameters(),lr=cfg['training']['diffusion_lr'],weight_decay=cfg['training']['diffusion_weight_decay'])
    nep=int(epochs or cfg['training']['diffusion_epochs']);acc=int(cfg['training']['diffusion_batch_size']);micro=int(cfg['training']['diffusion_micro_batch_size'])
    if acc%micro:raise ValueError('Effective batch size must be divisible by micro-batch size')
    train_loader=DataLoader(train,batch_size=micro,shuffle=True,num_workers=0)
    val_loader=DataLoader(val,batch_size=micro,shuffle=False,num_workers=0)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=nep)
    scaler=torch.amp.GradScaler('cuda',enabled=device.type=='cuda')
    start_epoch=0;history=[];best=float('inf')
    if resumed:
        if 'optimizer_state' not in resumed or 'scheduler_state' not in resumed:
            raise ValueError('Checkpoint contains model weights only; cannot claim exact optimizer-state resume')
        opt.load_state_dict(resumed['optimizer_state'])
        scheduler.load_state_dict(resumed['scheduler_state'])
        scaler.load_state_dict(resumed.get('scaler_state',{}))
        torch.set_rng_state(resumed['rng_torch'].cpu())
        if torch.cuda.is_available() and 'rng_cuda' in resumed:torch.cuda.set_rng_state_all(resumed['rng_cuda'])
        start_epoch=int(resumed['epoch']);best=float(resumed['validation_loss'])
        logfile=out/'training_log.csv'
        if logfile.exists():history=pd.read_csv(logfile).to_dict('records')
    save_json({'environment':env_record(),'effective_batch_size':acc,'micro_batch_size':micro,
               'simulation_class_neutral':neutral,'seed':cfg['seed']},out/'run_metadata.json')
    for epoch in range(start_epoch,nep):
        model.train();tr=[];opt.zero_grad(set_to_none=True);accum=0
        for batch,(ultra,clean,_) in enumerate(train_loader):
            ultra=ultra.to(device);clean=clean.to(device)
            with torch.autocast('cuda',enabled=device.type=='cuda'):
                loss=diffusion.loss(model,clean,ultra)
            scaler.scale(loss/(acc//micro)).backward();tr.append(float(loss.detach()));accum+=1
            if accum==(acc//micro) or batch==len(train_loader)-1:
                scaler.step(opt);scaler.update();opt.zero_grad(set_to_none=True);accum=0
        model.eval();vl=[]
        with torch.no_grad():
            for ultra,clean,_ in val_loader:
                vl.append(float(diffusion.loss(model,clean.to(device),ultra.to(device))))
        metric=float(np.mean(vl));scheduler.step()
        row={'epoch':epoch+1,'train_noise_mse':float(np.mean(tr)),'val_noise_mse':metric,'learning_rate':float(opt.param_groups[0]['lr'])}
        history.append(row);pd.DataFrame(history).to_csv(out/'training_log.csv',index=False)
        if metric<best:
            best=metric;save_checkpoint(model,out/'ddpm_best.pt',epoch+1,cfg,best,'ddpm',{'class_neutral':neutral},opt,scheduler,scaler)
        save_checkpoint(model,out/'ddpm_last.pt',epoch+1,cfg,metric,'ddpm',{'class_neutral':neutral},opt,scheduler,scaler)
        print(f'DDPM epoch {epoch+1}/{nep} train_mse={row["train_noise_mse"]:.5f} val_mse={metric:.5f}',flush=True)
    return str(out/'ddpm_best.pt')


class SyntheticClassification(Dataset):
    def __init__(self,cfg,split,size=None,limit=None):
        self.base=SyntheticPairs(cfg,split,size);self.length=min(len(self.base),limit) if limit else len(self.base)
    def __len__(self):return self.length
    def __getitem__(self,i):
        _,tissue,y=self.base[i]
        return tissue,y,f'synth_{self.base.offset+i:06d}'


class CachedRepresentations(Dataset):
    def __init__(self,npz):
        self.data=np.load(npz,allow_pickle=False)
    def __len__(self):return len(self.data['x'])
    def __getitem__(self,i):return (torch.from_numpy(self.data['x'][i].astype(np.float32)),torch.tensor(int(self.data['label'][i])),str(self.data['id'][i]))


def _dataset(cfg,manifest,split,mode,cache=None,limit=None):
    if cache:ds=CachedRepresentations(cache)
    elif mode=='synthetic':ds=SyntheticClassification(cfg,split,limit=limit)
    else:
        if manifest is None:raise ValueError('BUSI manifest required for this mode')
        basic={'uidm':'clahe','deterministic':'clahe'}.get(mode,mode)
        if mode in ('uidm','deterministic'):raise ValueError('Run build-features first, then provide --cache/--train-cache/--val-cache')
        ds=BusiDataset(manifest,split,cfg['image_size'],basic)
    if limit:ds=torch.utils.data.Subset(ds,range(min(limit,len(ds))))
    return ds


def train_classifier(cfg,out,manifest=None,mode='raw',train_cache=None,val_cache=None,init=None,epochs=None,limit=None):
    set_seed(cfg['seed']);device=get_device();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    model=make_classifier(cfg).to(device)
    if init:load_weights(model,init,device)
    train=_dataset(cfg,manifest,'train',mode,train_cache,limit)
    val=_dataset(cfg,manifest,'val',mode,val_cache,limit)
    trl=DataLoader(train,batch_size=cfg['training']['classifier_batch_size'],shuffle=True,num_workers=0)
    vl=DataLoader(val,batch_size=cfg['training']['classifier_batch_size'],shuffle=False,num_workers=0)
    opt=torch.optim.Adam(model.parameters(),lr=cfg['training']['classifier_lr'],weight_decay=cfg['training']['classifier_weight_decay'])
    nep=int(epochs or cfg['training']['classifier_epochs']);patience=cfg['training']['early_stop_patience']
    history=[];best=float('inf');since=0
    save_json({'environment':env_record(),'mode':mode,'seed':cfg['seed'],'init_checkpoint':init,'train_cache':train_cache,'val_cache':val_cache},out/'run_metadata.json')
    for epoch in range(nep):
        model.train();losses=[]
        for x,y,_ in trl:
            x=x.to(device);y=y.to(device);opt.zero_grad(set_to_none=True)
            loss=F.cross_entropy(model(x),y);loss.backward();opt.step();losses.append(float(loss.detach()))
        model.eval();vloss=[];correct=0;n=0
        with torch.no_grad():
            for x,y,_ in vl:
                x=x.to(device);y=y.to(device);logits=model(x)
                vloss.append((float(F.cross_entropy(logits,y,reduction='sum')),len(y)))
                correct+=int((logits.argmax(1)==y).sum());n+=len(y)
        val_loss=sum(a for a,_ in vloss)/max(1,sum(b for _,b in vloss))
        row={'epoch':epoch+1,'train_loss':float(np.mean(losses)),'val_loss':val_loss,'val_accuracy':correct/max(1,n)}
        history.append(row);pd.DataFrame(history).to_csv(out/'training_log.csv',index=False)
        if val_loss<best:
            best=val_loss;since=0;save_checkpoint(model,out/'classifier_best.pt',epoch+1,cfg,best,'classifier',{'mode':mode})
        else:since+=1
        save_checkpoint(model,out/'classifier_last.pt',epoch+1,cfg,val_loss,'classifier',{'mode':mode})
        print(f'CNN mode={mode} epoch {epoch+1}/{nep} val_loss={val_loss:.5f} val_acc={correct/max(1,n):.4f}',flush=True)
        if since>=patience:break
    return str(out/'classifier_best.pt')


def build_features(cfg,manifest,split,ddpm_checkpoint,out,mode='uidm',steps=200,det_checkpoint=None):
    if split not in ('train','val','test'):raise ValueError('Known split required')
    # This action is representation inference only: no optimization and no metric-based selection.
    set_seed(cfg['seed']);device=get_device()
    if mode=='uidm':
        model=make_ddpm(cfg).to(device);load_weights(model,ddpm_checkpoint,device)
        proc=DDPM(cfg,device)
    elif mode=='deterministic':
        model=DeterministicUNet().to(device)
        load_weights(model,det_checkpoint or ddpm_checkpoint,device)
    else:raise ValueError('Mode must be uidm or deterministic')
    model.eval()
    ds=BusiDataset(manifest,split,cfg['image_size'],'clahe')
    xs=[];ys=[];ids=[]
    with torch.no_grad():
        for i in range(len(ds)):
            x,y,ident=ds[i]
            inp=x[None].to(device)
            if mode=='uidm':result=proc.sample(model,inp,n_steps=steps)
            else:result=model(inp)
            xs.append(result[0].float().cpu().numpy().astype(np.float16))
            ys.append(int(y));ids.append(ident)
            if (i+1)%30==0:print(f'Cached {i+1}/{len(ds)} {split} representations',flush=True)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(out,x=np.stack(xs),label=np.array(ys),id=np.array(ids))
    return str(out)


def train_deterministic(cfg,out,epochs=50,limit=None):
    set_seed(cfg['seed']);device=get_device();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    model=DeterministicUNet().to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=cfg['training']['diffusion_lr'])
    tr=SyntheticPairs(cfg,'train');vl=SyntheticPairs(cfg,'val')
    if limit:tr=torch.utils.data.Subset(tr,range(min(limit,len(tr))));vl=torch.utils.data.Subset(vl,range(min(4,limit,len(vl))))
    trl=DataLoader(tr,batch_size=2,shuffle=True);vll=DataLoader(vl,batch_size=2)
    best=float('inf')
    for epoch in range(epochs):
        model.train()
        for us,tissue,_ in trl:
            us=us.to(device);tissue=tissue.to(device)
            opt.zero_grad();loss=F.mse_loss(model(us),tissue);loss.backward();opt.step()
        model.eval();losses=[]
        with torch.no_grad():
            for us,tissue,_ in vll:losses.append(float(F.mse_loss(model(us.to(device)),tissue.to(device))))
        val=float(np.mean(losses))
        if val<best:best=val;save_checkpoint(model,out/'deterministic_best.pt',epoch+1,cfg,val,'deterministic')
        print(f'Deterministic control epoch {epoch+1}/{epochs} validation MSE={val:.5f}',flush=True)
    return str(out/'deterministic_best.pt')


def evaluate_classifier(cfg,manifest,split,checkpoint,out,mode=None,cache=None,boot=2000,limit=None):
    if split not in ('train','val','test'):raise ValueError('Specify split explicitly')
    device=get_device();model=make_classifier(cfg).to(device);payload=load_weights(model,checkpoint,device)
    mode=mode or payload.get('extra',{}).get('mode','raw')
    ds=_dataset(cfg,manifest,split,mode,cache,limit)
    dl=DataLoader(ds,batch_size=cfg['training']['classifier_batch_size'],shuffle=False)
    records=[];model.eval()
    with torch.no_grad():
        for x,y,ids in dl:
            pred=model(x.to(device)).softmax(1).cpu().numpy()
            for ident,actual,p in zip(ids,y.tolist(),pred):
                records.append({'id':str(ident),'label':int(actual),'pred':int(p.argmax()),
                                'p_normal':float(p[0]),'p_benign':float(p[1]),'p_malignant':float(p[2])})
    result=write_prediction_report(pd.DataFrame(records),out,seed=cfg['seed'],boot=boot)
    save_json({'split':split,'model_mode':mode,'checkpoint':str(checkpoint),'cache':cache,
               'environment':env_record()},Path(out)/'evaluation_provenance.json')
    print(f'{split} N={result["n"]} accuracy={result["accuracy"]:.4f} macro_ovr_auc={result["macro_auc_ovr"]}',flush=True)
    return result


def _confidence_selection(cfg,ddpm,denoiser,clf,ultrasound,steps):
    """Operates on images only; no access to the true labels of unlabeled pool."""
    ss=cfg['semi_supervised'];K=int(ss['stochastic_reconstructions'])
    with torch.no_grad():
        samples=ddpm.multiple_reconstructions(denoiser,ultrasound,K,n_steps=steps)
        variance=samples.float().var(dim=0,unbiased=False).mean(dim=(1,2,3))
        mean_map=samples.mean(dim=0)
        probs=clf(mean_map).softmax(1)
        confidence,label=probs.max(1)
        entropy=-(probs*probs.clamp_min(1e-12).log()).sum(1)
        eligible=(variance<=ss['variance_threshold'])&(confidence>=ss['probability_threshold'])&(entropy<=ss['entropy_threshold_nats'])
        # Explicit reference weighting rule; source manuscript does not establish original code-level formula.
        ent_score=(1-entropy/np.log(3.)).clamp(0,1)
        var_score=(1-variance/ss['variance_threshold']).clamp(0,1)
        weights=ss['entropy_weight']*ent_score+ss['variance_weight']*var_score
    return mean_map,label,weights,eligible,variance,entropy,confidence


def adapt_classifier(cfg,manifest,ddpm_checkpoint,clf_checkpoint,out,steps=200,limit=None,update_diffusion=False):
    """Mask labels on a fixed training-only pool. Frozen DDPM by default.

    When update_diffusion=True, a clearly identified teacher-latent self-training
    objective is used; this option is NOT a verified recreation of historic runs.
    """
    set_seed(cfg['seed']);device=get_device();out=Path(out);out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(manifest);validate_manifest(df)
    train=df[df.split=='train'].copy().reset_index(drop=True)
    if limit:train=train.iloc[:limit].copy()
    if train.empty:raise ValueError('No training images')
    # A fixed training-only split; only this step uses class labels for stratification.
    rng=np.random.default_rng(cfg['seed']+71)
    keep=np.ones(len(train),dtype=bool)
    for cls in (0,1,2):
        ix=np.flatnonzero(train.label.to_numpy()==cls)
        rng.shuffle(ix)
        keep[ix[:int(len(ix)*cfg['semi_supervised']['unlabeled_train_fraction'])]]=False
    labeled=train[keep];unlabeled=train[~keep]
    if len(labeled)==0 or len(unlabeled)==0:raise ValueError('Choose valid labeled/unlabeled fraction and dataset size')
    denoiser=make_ddpm(cfg).to(device);load_weights(denoiser,ddpm_checkpoint,device)
    clf=make_classifier(cfg).to(device);load_weights(clf,clf_checkpoint,device)
    ddpm=DDPM(cfg,device);denoiser.eval()
    for p in denoiser.parameters():p.requires_grad_(bool(update_diffusion))
    opt=torch.optim.Adam(clf.parameters(),lr=cfg['semi_supervised']['learning_rate'])
    diffusion_opt=(torch.optim.AdamW(denoiser.parameters(),lr=cfg['training']['diffusion_lr']*.1)
                   if update_diffusion else None)
    history=[];best=float('inf')
    ss=cfg['semi_supervised']
    save_json({'environment':env_record(),'seed':cfg['seed'],'train_images':int(len(train)),
        'labeled_training':len(labeled),'masked_unlabeled_training':len(unlabeled),
        'freeze_diffusion':not update_diffusion,'pseudo_weight_rule':'0.5(1-H/log3)+0.5(1-v/tau_v), clipped',
        'pseudo_selection_only_training_images':True},out/'adaptation_provenance.json')
    def mapped_image(path):return torch.tensor(preprocess(path,cfg['image_size'],'clahe'))[None].to(device)
    for rnd in range(int(ss['rounds'])):
        denoiser.eval();clf.eval();selected=[];v_all=[];h_all=[];count=0
        for _,r in unlabeled.iterrows():
            x=mapped_image(r.path)
            m,p,w,eligible,var,ent,conf=_confidence_selection(cfg,ddpm,denoiser,clf,x,steps)
            v_all.append(float(var[0]));h_all.append(float(ent[0]))
            if bool(eligible[0]):
                selected.append((r.id,m[0].detach().cpu(),int(p[0]),float(w[0]),str(r.path)))
            count+=1
            if count%20==0:print(f'Adapt round {rnd+1}: pseudo-screened {count}/{len(unlabeled)}',flush=True)
        # Labeled branch: only observed training annotations, not validation/test.
        labeled_features=[]
        with torch.no_grad():
            for _,r in labeled.iterrows():
                lat=ddpm.sample(denoiser,mapped_image(r.path),n_steps=steps)
                labeled_features.append((lat[0].cpu(),int(r.label)))
        clf.train()
        for _ in range(int(ss['pseudo_epochs_per_round'])):
            rng.shuffle(labeled_features);rng.shuffle(selected)
            for latent,y in labeled_features:
                opt.zero_grad(set_to_none=True)
                loss=F.cross_entropy(clf(latent[None].to(device)),torch.tensor([y],device=device))
                loss.backward();opt.step()
            for _,latent,y,w,_ in selected:
                opt.zero_grad(set_to_none=True)
                loss=ss['pseudo_loss_weight']*w*F.cross_entropy(
                    clf(latent[None].to(device)),torch.tensor([y],device=device))
                loss.backward();opt.step()
        if update_diffusion and selected:
            denoiser.train()
            for _,lat,_,_,path in selected:
                diffusion_opt.zero_grad(set_to_none=True)
                # Teacher-generated pseudo tissue latent is detached (no real physical ground truth).
                loss=ddpm.loss(denoiser,lat[None].to(device),mapped_image(path))
                loss.backward();diffusion_opt.step()
            denoiser.eval()
        # Validation used for checkpointing only; not pseudo-labeling/parameter updates.
        val=BusiDataset(manifest,'val',cfg['image_size'],'clahe')
        clf.eval();ncorrect=0;total=0;vsum=0.
        with torch.no_grad():
            for j in range(len(val)):
                x,y,_=val[j]
                latent=ddpm.sample(denoiser,x[None].to(device),n_steps=steps)
                logits=clf(latent)
                vsum+=float(F.cross_entropy(logits,torch.tensor([int(y)],device=device)))
                ncorrect+=int(logits.argmax(1).item()==int(y));total+=1
        val_loss=vsum/max(1,total)
        row={'round':rnd+1,'pseudo_eligible':len(selected),'pseudo_pool':len(unlabeled),
             'unlabeled_mean_variance':float(np.mean(v_all)),
             'unlabeled_mean_entropy':float(np.mean(h_all)),
             'val_loss':val_loss,'val_accuracy':ncorrect/max(1,total)}
        history.append(row);pd.DataFrame(history).to_csv(out/'adaptation_rounds.csv',index=False)
        if val_loss<best:
            best=val_loss;save_checkpoint(clf,out/'adapted_classifier_best.pt',rnd+1,cfg,val_loss,'classifier',{'mode':'uidm','adapted':True})
            if update_diffusion:save_checkpoint(denoiser,out/'adapted_ddpm_best.pt',rnd+1,cfg,val_loss,'ddpm',{'self_training':True})
        pd.DataFrame([{'id':a[0],'pseudo_label':a[2],'confidence_weight':a[3]} for a in selected],
            columns=['id','pseudo_label','confidence_weight']).to_csv(out/f'pseudo_round_{rnd+1}.csv',index=False)
        print(f'Round {rnd+1}: selected {len(selected)}/{len(unlabeled)}; val={ncorrect/max(1,total):.4f}',flush=True)
    return str(out/'adapted_classifier_best.pt')


def evaluate_reconstruction(cfg,checkpoint,out,split='test',steps=200,limit=None):
    """Actual synthetic paired reference evaluation: MSE, PSNR, SSIM, time/image."""
    import time
    from skimage.metrics import structural_similarity as ssim
    set_seed(cfg['seed']);device=get_device()
    model=make_ddpm(cfg).to(device);load_weights(model,checkpoint,device)
    ddpm=DDPM(cfg,device);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    data=SyntheticPairs(cfg,split);records=[]
    n=min(len(data),limit) if limit else len(data)
    for i in range(n):
        ultra,truth,y=data[i]
        if device.type=='cuda':torch.cuda.synchronize()
        begin=time.perf_counter()
        pred=ddpm.sample(model,ultra[None].to(device),n_steps=steps)[0,0].cpu().numpy()
        if device.type=='cuda':torch.cuda.synchronize()
        seconds=time.perf_counter()-begin
        real=truth[0].numpy();mse=float(np.mean((real-pred)**2))
        records.append({'sample_index':data.offset+i,'label':int(y),'mse':mse,
            'psnr_db':float(10*np.log10(1/max(mse,1e-12))),
            'ssim':float(ssim(real,pred,data_range=1.0)),'inference_seconds':seconds})
        if (i+1)%30==0:print(f'Reconstruction evaluated {i+1}/{n}',flush=True)
    frame=pd.DataFrame(records);frame.to_csv(out/'reconstruction_per_sample.csv',index=False)
    results={'n':n,'sampling_steps':steps,'split':split,'metrics':{}}
    rng=np.random.default_rng(cfg['seed'])
    for key in ('mse','psnr_db','ssim','inference_seconds'):
        vals=frame[key].to_numpy();means=[]
        for _ in range(cfg['reporting']['bootstrap_rounds']):
            means.append(float(rng.choice(vals,size=len(vals),replace=True).mean()))
        results['metrics'][key]={'mean':float(vals.mean()),'sd':float(vals.std(ddof=1)) if len(vals)>1 else 0.,
            'bootstrap_mean_95ci':list(map(float,np.quantile(means,[.025,.975])))}
    results['note']='Synthetic reference evaluation only; no claim about quantitative clinical tissue properties.'
    save_json(results,out/'reconstruction_summary.json')
    print('SYNTHETIC RECONSTRUCTION:',results['metrics'],flush=True)
    return results
